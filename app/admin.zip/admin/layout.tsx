import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import LogoutButton from "@/components/LogoutButton";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profile?.role !== "admin") redirect("/dashboard");

  return (
    <div className="min-h-screen flex flex-col bg-gray-950">
      {/* TOPBAR */}
      <header className="bg-gray-900 border-b border-gray-800 h-14 flex items-center px-6 gap-4 flex-shrink-0">
        <Link href="/admin" className="flex items-center gap-2">
          <span className="text-lg">🦉</span>
          <span className="font-black text-white text-lg">PropertyOwl <span className="text-[#E8001D]">Admin</span></span>
        </Link>
        <div className="w-px h-5 bg-gray-700" />
        <span className="text-xs text-gray-500 font-medium">Management Portal</span>
        <div className="flex-1" />
        <Link href="/dashboard" className="text-xs text-gray-400 hover:text-white transition-colors mr-2">
          ← User Portal
        </Link>
        <LogoutButton />
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* SIDEBAR */}
        <aside className="w-56 bg-gray-900 border-r border-gray-800 flex-shrink-0 py-4">
          <nav className="space-y-0.5 px-3">
            <p className="text-xs font-bold text-gray-600 uppercase tracking-wider px-2 py-2">Overview</p>
            {[
              { href: "/admin", icon: "📊", label: "Dashboard" },
              { href: "/admin/users", icon: "👥", label: "Users" },
              { href: "/admin/reports", icon: "📄", label: "Reports" },
            ].map((item) => (
              <Link key={item.href} href={item.href}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white transition-colors">
                <span>{item.icon}</span><span>{item.label}</span>
              </Link>
            ))}

            <p className="text-xs font-bold text-gray-600 uppercase tracking-wider px-2 py-2 mt-3">Settings</p>
            {[
              { href: "/admin/settings/content", icon: "✏️", label: "Content" },
              { href: "/admin/settings/llm", icon: "🤖", label: "LLM Settings" },
              { href: "/admin/settings/pricing", icon: "💳", label: "Pricing" },
              { href: "/admin/settings/system", icon: "⚙️", label: "System" },
            ].map((item) => (
              <Link key={item.href} href={item.href}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-gray-400 hover:bg-gray-800 hover:text-white transition-colors">
                <span>{item.icon}</span><span>{item.label}</span>
              </Link>
            ))}
          </nav>
        </aside>

        <main className="flex-1 overflow-y-auto p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
