import { createClient } from "@/lib/supabase/server";

export default async function AdminDashboard() {
  const supabase = await createClient();

  const [
    { count: userCount },
    { count: reportCount },
    { data: recentUsers },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("reports").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(5),
  ]);

  return (
    <div>
      <div className="mb-8">
        <p className="text-xs font-bold text-[#E8001D] uppercase tracking-wider mb-1">Admin</p>
        <h1 className="text-3xl font-black text-white">Dashboard</h1>
        <p className="text-gray-500 mt-1">PropertyOwl AI — management overview</p>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Total Users", value: userCount ?? 0, color: "text-white" },
          { label: "Reports Run", value: reportCount ?? 0, color: "text-white" },
          { label: "Active Today", value: 0, color: "text-white" },
          { label: "Revenue (AUD)", value: "$0", color: "text-[#E8001D]" },
        ].map((s) => (
          <div key={s.label} className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">{s.label}</p>
            <p className={`text-4xl font-black ${s.color} leading-none`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* RECENT USERS */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h2 className="text-base font-black text-white mb-4">Recent Users</h2>
        {!recentUsers || recentUsers.length === 0 ? (
          <p className="text-gray-500 text-sm">No users yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left py-2 text-xs font-bold text-gray-500 uppercase tracking-wide">Name</th>
                <th className="text-left py-2 text-xs font-bold text-gray-500 uppercase tracking-wide">Email</th>
                <th className="text-left py-2 text-xs font-bold text-gray-500 uppercase tracking-wide">Credits</th>
                <th className="text-left py-2 text-xs font-bold text-gray-500 uppercase tracking-wide">Joined</th>
              </tr>
            </thead>
            <tbody>
              {recentUsers.map((u) => (
                <tr key={u.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                  <td className="py-3 text-white font-medium">{u.full_name || "—"}</td>
                  <td className="py-3 text-gray-400">{u.email}</td>
                  <td className="py-3 text-white">{u.credits ?? 0}</td>
                  <td className="py-3 text-gray-500">{new Date(u.created_at).toLocaleDateString("en-AU")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
